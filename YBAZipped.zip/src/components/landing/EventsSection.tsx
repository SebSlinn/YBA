//src/components/landing/EventsSection.tsx

export default function EventsSection() {
  return (
    <section className="relative overflow-hidden bg-white">

      {/* Navy fade — same treatment as News/QuickLinks above it */}
      <div
        className="absolute top-0 left-0 right-0"
        style={{
          height: "var(--header-height, 64px)",
          background:
            "linear-gradient(to bottom, rgba(var(--yba-navy-rgb, 47, 53, 89),1) 0%, rgba(var(--yba-navy-rgb, 47, 53, 89),0) 100%)",
        }}
      />

      {/* Magenta Bar — this section's accent colour, cycling back round from the hero */}
      <div className="absolute bottom-0 left-0 h-[4px] w-full bg-[var(--yba-magenta,#D5008F)]" />

      <div className="relative mx-auto max-w-[var(--content-width,1400px)] px-6 pb-20 pt-24 sm:px-10 md:px-[var(--page-padding,48px)]">
        <h2
          className="text-2xl font-bold sm:text-3xl"
          style={{ color: "var(--yba-navy, #2F3559)" }}
        >
          Events
        </h2>
      </div>

    </section>
  );
}
