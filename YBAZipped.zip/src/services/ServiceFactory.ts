//frontend/src/services/ServiceFactory.ts

import { MockNewsService } from "./mock/MockNewsService";
import { DirectusNewsService } from "./directus/DirectusNewsService";
import { INewsService } from "./interfaces/INewsService";

const useMock = false;

export const NewsService: INewsService =
    new DirectusNewsService();
  