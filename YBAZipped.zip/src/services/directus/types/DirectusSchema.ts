//frontend/src/services/directus/types/DirectusSchema.ts

import { DirectusNews } from "./DirectusNews";

export interface DirectusSchema {
    news: DirectusNews[];
}