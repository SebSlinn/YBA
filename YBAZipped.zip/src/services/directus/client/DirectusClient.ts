// src/services/directus/client/DirectusClient.ts

import { createDirectus, rest } from "@directus/sdk";

const url =
  process.env.NEXT_PUBLIC_DIRECTUS_URL ??
  "http://localhost:8055";

export const directus = createDirectus(url).with(rest());

export function getAssetUrl(fileId: string): string {
  return `${url}/assets/${fileId}`;
}